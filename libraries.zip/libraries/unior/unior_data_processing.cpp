#include "unior_data_processing.h"
#include "unior_filters.h"

DataProcessing* create_data_processing_on_channel_type(std::string& ch_type)
//std::unique_ptr<DataProcessing> create_data_processing_on_channel_type(std::string& ch_type)
{
	/// creating buffers & processing object here
	DataProcessing* data_processing;
	
	if (ch_type == "EEG")
	{ 
		data_processing = new EEG_Raw_Processing();
	} else

	if (ch_type == "EMG")
	{ 
		data_processing = new EMG_Raw_Processing();
	} else

	if (ch_type == "ECG")
	{ 
		data_processing = new ECG_Raw_Processing();
	} else

	if (ch_type == "PPG")
	{ 
		data_processing = new PPG_Raw_Processing();
	} else

	if (ch_type == "GSR")
	{ 
		data_processing = new GSR_Raw_Processing();
	} else

	if (ch_type == "TEMP")
	{ 
		data_processing = new TEMP_Raw_Processing();
	} else

	if (ch_type == "BREATH")
	{ 
		data_processing = new BREATH_Raw_Processing();
	} else

	/// unknown type
	{
		data_processing = new Default_Processing();
	}
	
	return data_processing;
}
