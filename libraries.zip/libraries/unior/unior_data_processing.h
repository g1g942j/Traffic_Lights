#ifndef _UNIOR_DATA_PROCESSING_H
#define _UNIOR_DATA_PROCESSING_H

#include <iostream>
#include <string>
#include <memory>
#include "unior_filters.h"

class DataProcessing;

DataProcessing* create_data_processing_on_channel_type(std::string& ch_type);

		
class DataProcessing 
{
	public:
		BSFilter_50* bsf_50;

	public:
		DataProcessing()  
		{
			bsf_50 = new BSFilter_50();
		};
		
		virtual ~DataProcessing() 
		{
			delete bsf_50;
		};
		
		virtual bool process(float input_v, float& output_v) = 0;
};


class EEG_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
		LPFilter_25* lpf_25;
		HPFilter_EEG* hpf;
	
	public:
		EEG_Raw_Processing() 
		{
			counter = 0;
			lpf_25 = new LPFilter_25();
			hpf = new HPFilter_EEG();
		};
	
		~EEG_Raw_Processing() 
		{
			delete lpf_25;
			delete hpf;
		};
	
		
		virtual bool process(float input_v, float& output_v)
		{
			output_v = hpf -> filter(lpf_25 -> filter(bsf_50 -> filter(input_v)));
			return counter++ % 4 == 0;			// arduino 	-  62.5 samples per second
		};
};


class EMG_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
		HPFilter_15* hpf_15;
		WaveFilter* wf;
	
	public:
		EMG_Raw_Processing() 
		{
			counter = 0;
			hpf_15 = new HPFilter_15();
			wf = new WaveFilter(25, 0);
		};
	
		~EMG_Raw_Processing() 
		{
			delete hpf_15;
			delete wf;
		};
	
		virtual bool process(float input_v, float& output_v)
		{
			output_v = hpf_15 -> filter(bsf_50 -> filter(input_v));
			output_v = wf -> filter(output_v);
			return counter++ % 25 == 0;		// arduino 	-  10 samples per second
		};
};


class ECG_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
		LPFilter_35* lpf_35;
		HPFilter_ECG* hpf;
	
	public:
		ECG_Raw_Processing() 
		{
			counter = 0;
			lpf_35 = new LPFilter_35();
			hpf = new HPFilter_ECG();
		};
	
		~ECG_Raw_Processing() 
		{
			delete lpf_35;
			delete hpf;
		};
		
		virtual bool process(float input_v, float& output_v)
		{
			output_v = hpf -> filter(lpf_35 -> filter(bsf_50 -> filter(input_v)));
			return counter++ % 2 == 0;			// arduino 	- 125 samples per second
		};
};


class PPG_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
		HPFilter_0_1* hpf; // 0.1 Hz
		LPFilter_10* lpf;
	
	public:
		PPG_Raw_Processing() 
		{
			counter = 0;
			hpf = new HPFilter_0_1();
			lpf = new LPFilter_10();
		};
	
		~PPG_Raw_Processing() 
		{
			delete lpf;
			delete hpf;
		};
		
		virtual bool process(float input_v, float& output_v)
		{
			output_v = lpf -> filter(hpf -> filter(bsf_50 -> filter(input_v)));
			return counter++ % 2 == 0;			// arduino 	- 125 samples per second
		};
};


class GSR_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
	
	public:
		GSR_Raw_Processing() 
		{
			counter = 0;
		};
	
		virtual bool process(float input_v, float& output_v)
		{
			output_v = bsf_50 -> filter(input_v);
			return counter++ % 25 == 0;		// arduino 	-  10 samples per second
		};
};


class TEMP_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
	    LPFilter_5* lpf;
	    
	public:
		TEMP_Raw_Processing() 
		{
			counter = 0;
			lpf = new LPFilter_5();
		};
	
		~TEMP_Raw_Processing() 
		{
			delete lpf;
		};
		
		virtual bool process(float input_v, float& output_v)
		{
			output_v = lpf -> filter(bsf_50 -> filter(input_v));
			return counter++ % 25 == 0;		// arduino 	-  10 samples per second
		};
};


class BREATH_Raw_Processing : public DataProcessing
{
	private:
		uint32_t counter;
		LPFilter_10* lpf;
		HPFilter_0_1* hpf;
	
	public:
		BREATH_Raw_Processing() 
		{
			counter = 0;
			lpf = new LPFilter_10();
			hpf = new HPFilter_0_1();
		};
	
		~BREATH_Raw_Processing() 
		{
			counter = 0;
			delete lpf;
			delete hpf;
		};
		
		virtual bool process(float input_v, float& output_v)
		{
			if (counter == 0) hpf -> init(input_v*10);

			output_v = lpf -> filter(hpf -> filter(bsf_50 -> filter(input_v*10)));
			return counter++ % 10 == 0;		// arduino 	-  25 samples per second
		};
};


class Default_Processing : public DataProcessing
{
	private:
	
	public:
	    Default_Processing() 
	    {
		}
		
		virtual bool process(float input_v, float& output_v)
		{
			output_v = input_v;
			return true;
		};
};

#endif // _UNIOR_DATA_PROCESSING_H