#ifndef _UNIOR_H_
#define _UNIOR_H_

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEScan.h>

//#define _PRINT_INFO_
#ifdef _PRINT_INFO_
  #define DEBUGLN(X) Serial.println(X)
  #define DEBUG(X) Serial.print(X)
#else
  #define DEBUGLN(X)
  #define DEBUG(X)
#endif

class UniorAdvertisedDeviceCallbacks;

class UniorBLEModule
{
  friend class UniorAdvertisedDeviceCallbacks;

  private:
    BLEAdvertisedDevice device;
    bool found;
    bool is_connected;

    BLERemoteCharacteristic* pCmdCharacteristic;
    BLERemoteCharacteristic* pDataCharacteristic;
  public:
    UniorBLEModule(String mac_address);
    ~UniorBLEModule();

    bool connect(int timeout_sec = 0);
    bool start();

    float battery_level;
    bool read(float& value);
    
    bool connected() { return is_connected; };
    String mac_address;

    bool queue_overflow;
    QueueHandle_t dataQueue;
};

#endif //_UNIOR_H_

