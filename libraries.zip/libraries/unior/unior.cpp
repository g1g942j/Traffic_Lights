#include "unior.h"
#include <map>

typedef std::map<BLERemoteCharacteristic*, UniorBLEModule*> Charactristic2ModuleMap;

Charactristic2ModuleMap char_map;


static BLEUUID serviceUUID("e54eeef0-1980-11ea-836a-2e728ce88125");
static BLEUUID DATA_CHARACTERISTIC_UUID("e54eeef1-1980-11ea-836a-2e728ce88125");
static BLEUUID CMD_CHARACTERISTIC_UUID("e54e0002-1980-11ea-836a-2e728ce88125");

class UniorAdvertisedDeviceCallbacks: public BLEAdvertisedDeviceCallbacks 
{
  String mac;
  UniorBLEModule* module;
  public:
    UniorAdvertisedDeviceCallbacks(String mac, UniorBLEModule* module) { this->mac = mac; this->module = module; }

    // Called for each advertising UNIor BLE module.
    void onResult(BLEAdvertisedDevice advertisedDevice) 
    {
      #ifdef _PRINT_INFO_
      Serial.printf("Advertised Device: %s \n", advertisedDevice.toString().c_str());
      #endif
    
      if (advertisedDevice.getAddress().equals(BLEAddress(mac.c_str())))
      {
        DEBUGLN("Device found...");
        module->device = advertisedDevice;
        module->found = true;
        BLEDevice::getScan()->stop();
      } // Found our module
    } // onResult
}; // UniorAdvertisedDeviceCallbacks


UniorBLEModule::UniorBLEModule(String mac_address) 
{ 
  this->mac_address = mac_address; 
  dataQueue = xQueueCreate(100, sizeof(float));
  
  is_connected = false;
  found = false;
  queue_overflow = false;

  battery_level = 0;
  DEBUGLN("Create module");
};


UniorBLEModule::~UniorBLEModule() 
{ 
}


class UniorClientCallback : public BLEClientCallbacks 
{
  void onConnect(BLEClient* pclient) {}

  void onDisconnect(BLEClient* pclient) 
  {
    //is_connected = false;
    DEBUGLN("onDisconnect");
  }
};


static void notifyCallback(BLERemoteCharacteristic* pBLERemoteCharacteristic, uint8_t* pData, size_t length, bool isNotify) 
{
    UniorBLEModule* module = char_map.at(pBLERemoteCharacteristic);
    if (module == nullptr) return;

    float *pv = (float*) pData; 
    pv++; // skip packet time
    
    module->battery_level = *pv; // battery level, %
    pv++; 
    int cnt = length / sizeof(float);
    for (int i = 2 ; i < cnt; i++) 
    {
      if(uxQueueSpacesAvailable(module->dataQueue) == 0)
      {
        module->queue_overflow = true;
        //DEBUGLN("Code is slow, some data is deleted!!!!");
        float tmp;
        xQueueReceive(module->dataQueue, &tmp, 0);
      }
      xQueueSend(module->dataQueue, pv, portMAX_DELAY);
      pv++;
    }
}

// connect to UNIor BLE module
bool UniorBLEModule::connect(int timeout_sec) // def value = 0 
{
    if (is_connected) return true;

    DEBUG("Forming a connection to ");
    DEBUGLN(mac_address.c_str());
    
  if (!BLEDevice::getInitialized())
{
    BLEDevice::init("");
 }   
    BLEScan* pBLEScan = BLEDevice::getScan();
    pBLEScan->setAdvertisedDeviceCallbacks(new UniorAdvertisedDeviceCallbacks(mac_address, this));
    pBLEScan->setActiveScan(true);
    pBLEScan->setInterval(100);
    pBLEScan->setWindow(99);
    pBLEScan->start(timeout_sec, false); // waiting for, seconds (0 = infinite)

    //DEBUGLN("Device found (connect)...");
    //delay(100); // 
    if (!found) return false;

    BLEClient*  pClient  = BLEDevice::createClient();
    DEBUG(" - Created client");
    pClient->setClientCallbacks(new UniorClientCallback());

    // Connect to UNIor BLE module.
    pClient->connect(&device);  // if you pass BLEAdvertisedDevice instead of address, it will be recognized type of peer device address (public or private)
    DEBUGLN(" - Connected to module");
    // Obtain a reference to the service we are after in the UNIor BLE module.
    BLERemoteService* pRemoteService = pClient->getService(serviceUUID);
    if (pRemoteService == nullptr) 
    {
      DEBUG("Failed to find our service UUID: ");
      DEBUGLN(serviceUUID.toString().c_str());
      pClient->disconnect();
      return false;
    }
    
    DEBUGLN(" - Found our service");
    // Obtain a reference to the characteristic in the service of the UNIor BLE module.
    pDataCharacteristic = pRemoteService->getCharacteristic(DATA_CHARACTERISTIC_UUID);
    
    if (pDataCharacteristic == nullptr) 
    {
      DEBUG("Failed to find data characteristic UUID: ");
      DEBUGLN(DATA_CHARACTERISTIC_UUID.toString().c_str());
      pClient->disconnect();
      return false;
    }
    DEBUGLN(" - Found data characteristic");
    // Obtain a reference to the characteristic in the service of the UNIor BLE module.
    pCmdCharacteristic = pRemoteService->getCharacteristic(CMD_CHARACTERISTIC_UUID);
    
    if (pCmdCharacteristic == nullptr) 
    {
      
      DEBUG("Failed to find cmd characteristic UUID: ");
      DEBUGLN(CMD_CHARACTERISTIC_UUID.toString().c_str());
      pClient->disconnect();
      return false;
    }

    DEBUGLN(" - Found cmd characteristic");
    if (pDataCharacteristic->canNotify()) 
    {
      pDataCharacteristic->registerForNotify(notifyCallback);
      DEBUGLN(" - Notify");
    }

    // send start command to UNIor BLE module
    /*if (pCmdCharacteristic->canWrite()) 
    {
      uint8_t cmd[6] = {'S', 'T', 'A', 'R', 'T', 0};
      pCmdCharacteristic->writeValue(cmd, 6);
      DEBUGLN(" - start");
    }*/

    char_map.insert(std::make_pair(pDataCharacteristic, this));

    is_connected = true;
    return true;
}


bool UniorBLEModule::start()
{
    if (is_connected && pCmdCharacteristic->canWrite()) 
    {
      uint8_t cmd[6] = {'S', 'T', 'A', 'R', 'T', 0};
      pCmdCharacteristic->writeValue(cmd, 6);
      DEBUGLN(" - start");
      return true;
    }
    else
    {
      DEBUGLN(" - not started...");
      return false;
    }
}
  

bool UniorBLEModule::read(float& value)
{
  return xQueueReceive(dataQueue, &value, 0) == pdTRUE;
}
