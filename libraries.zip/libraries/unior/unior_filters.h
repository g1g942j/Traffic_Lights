#ifndef _UNIOR_FILTERS_H
#define _UNIOR_FILTERS_H

#include <cmath>

const int maxNumberOfCoefficients = 16;

class  IIRFilterBase
{
  public:
    IIRFilterBase()
    {
      NumberOfCoefficients = 0;

      for (int i = 0; i <= maxNumberOfCoefficients; i++) {
        InputValues[i] = 0;
        OutputValues[i] = 0;
      }
    }
      
  protected:
  //public:
    int NumberOfCoefficients;

    double FGain;
    double InputValues[maxNumberOfCoefficients+1], OutputValues[maxNumberOfCoefficients+1];
    double InputCoefficients[maxNumberOfCoefficients];
    double OutputCoefficients[maxNumberOfCoefficients];
    
  public:
    float filter(float InputValue) {
      int i;
      for (i = 0; i < NumberOfCoefficients; i++) {
        InputValues[i]  = InputValues[i + 1];
        OutputValues[i] = OutputValues[i + 1];
      }

    double Result = double(InputValue) * FGain;
    InputValues[NumberOfCoefficients] = Result;

    for (i = 0; i < NumberOfCoefficients; i++) {
      Result = Result + InputValues[i] * InputCoefficients[i] +
      OutputValues[i] * OutputCoefficients[i];
    }

    OutputValues[NumberOfCoefficients] = Result;
    return float(Result);
   }
};

class WaveFilter
{
  public:
    WaveFilter(int cnt, float init_value) {
      samples_count = cnt;
      start_value = init_value;
      reset();
    }

    float filter(float v) {
      temp_value = fmax(temp_value, fabs(v));
      if (++current_cnt >= samples_count) {
        calculated_value = temp_value;
        current_cnt = 0;
        temp_value = start_value;
      }

      return calculated_value;
    }

    void reset() {
      calculated_value = start_value;
      temp_value = start_value;
      current_cnt = 0;
    }

  private:
    float temp_value, calculated_value, start_value;
    int samples_count, current_cnt;
};


// частота дискретизации устройства 250 Гц

// обработка для ЭМГ
// 1. Отфильтровываем 50 Гц полосовым фильтром второго порядка
// 2. Выпрямляем сигнал (fabs)
// 3. Пропускаем через wave filter (время интеграции 100 мс)
// 4. Сглаживаем сигнал фильтром первого порядка и прореживаем до 10 значений в секунду 
//    (optional)

// Обработка для ЭЭГ
// 1. Отфильтровываем 50 Гц полосовым фильтром второго порядка
// 2. Применяем фильтр второго порядка на 25 Гц
// 3. Делаем даунсэмплинг до 62.5 Гц
// 4. Выделяем альфа-ритм полосовым фильтром (10 значений в секунду)
//    (optional)
// 5. Выделяем бета-ритм полосовым фильтром (10 samples per second)
//    (optional)

//
// Butterworth, Bandstop, order = 2, f1 = 45, f2 = 55, SR = 250
class  BSFilter_50 : public IIRFilterBase
{
  public:
    BSFilter_50():IIRFilterBase()
    {
    NumberOfCoefficients = 4;
      FGain = 8.37089190566345E-001;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = -1.24589220970327E+000;
      InputCoefficients[2] = 2.38806184954982E+000;
      InputCoefficients[3] = -1.24589220970327E+000;

      OutputCoefficients[0] = -7.00896781188402E-001;
      OutputCoefficients[1] = 9.49760308799785E-001;
      OutputCoefficients[2] = -1.97230236060631E+000;
      OutputCoefficients[3] = 1.13608549390706E+000;
    }
};

// Butterworth, Lowpass, order = 2, f = 25, SR = 250
class  LPFilter_25 : public IIRFilterBase
{
  public:
    LPFilter_25():IIRFilterBase()
    {
      NumberOfCoefficients = 2;
      FGain = 6.74552738890719E-002;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 2.00000000000000E+000;

      OutputCoefficients[0] = -4.12801598096189E-001;
      OutputCoefficients[1] = 1.14298050253990E+000;
    }
};

// Butterworth, Lowpass, order = 2, f = 35, SR = 250
class  LPFilter_35 : public IIRFilterBase
{
  public:
    LPFilter_35():IIRFilterBase()
    {
      NumberOfCoefficients = 2;
      FGain = 1.17351036724609E-001;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 2.00000000000000E+000;

      OutputCoefficients[0] = -2.94636527587915E-001;
      OutputCoefficients[1] = 8.25232380689478E-001;
    }
};

// Butterworth, Highpass, order = 2, f = 15, SR = 250
class  HPFilter_15 : public IIRFilterBase
{
  public:
    HPFilter_15():IIRFilterBase()
    {
      NumberOfCoefficients = 2;
      FGain = 7.65599987913459E-001;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = -2.00000000000000E+000;

      OutputCoefficients[0] = -5.86919508061190E-001;
      OutputCoefficients[1] = 1.47548044359265E+000;
    }
};


// Butterworth, Highpass, order = 1, f = 2.5, SR = 250
class  HPFilter_EEG : public IIRFilterBase
{
  public:
    HPFilter_EEG():IIRFilterBase()
    {
      NumberOfCoefficients = 1;
      FGain = 9.69531252908746E-001;

      InputCoefficients[0] = -1.00000000000000E+000;

      OutputCoefficients[0] = 9.39062505817492E-001;
    }
};

// Butterworth, Highpass, order = 1, f = 0.5, SR = 250
class  HPFilter_ECG : public IIRFilterBase
{
  public:
    HPFilter_ECG():IIRFilterBase()
    {
      NumberOfCoefficients = 1;
      FGain = 9.93755964953657E-001;

      InputCoefficients[0] = -1.00000000000000E+000;

      OutputCoefficients[0] = 9.87511929907314E-001;
    }
};


// Butterworth, Lowpass, order = 2, f = 10, SR = 250
class  LPFilter_10 : public IIRFilterBase
{
  public:
    LPFilter_10():IIRFilterBase()
    {
      NumberOfCoefficients = 2;
      FGain = 1.33592000278565E-002;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 2.00000000000000E+000;

      OutputCoefficients[0] = -7.00896781188403E-001;
      OutputCoefficients[1] = 1.64745998107698E+000;
    }
};

// Butterworth, Lowpass, order = 2, f = 5, SR = 250
class  LPFilter_5 : public IIRFilterBase
{
  public:
    LPFilter_5():IIRFilterBase()
    {
      NumberOfCoefficients = 2;
      FGain = 3.62168151492862E-003;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 2.00000000000000E+000;

      OutputCoefficients[0] = -8.37181651256023E-001;
      OutputCoefficients[1] = 1.82269492519631E+000;
    }
};

// Butterworth, Highpass, order = 1, f = 0.05, SR = 250
class  HPFilter_0_05 : public IIRFilterBase
{
  public:
    HPFilter_0_05():IIRFilterBase()
    {
      NumberOfCoefficients = 1;
      FGain = 9.99372075922984E-001;

      InputCoefficients[0] = -1.00000000000000E+000;

      OutputCoefficients[0] = 9.98744151845968E-001;
    }
};

// Butterworth, Highpass, order = 1, f = 0.1, SR = 250
class  HPFilter_0_1 : public IIRFilterBase
{
  public:
    HPFilter_0_1():IIRFilterBase()
    {
      NumberOfCoefficients = 1;
      FGain = 9.98744939433549E-001;

      InputCoefficients[0] = -1.00000000000000E+000;

      OutputCoefficients[0] = 9.97489878867098E-001;
    }
    
    void init(float start_value)
    {
      InputValues[0] = start_value * FGain;
      InputValues[1] = start_value * FGain;
    }
};

/*
// Butterworth, Lowpass, order = 1, f = 10, SR = 120
class  LPFilter1_10_120 : public IIRFilterBase
{
  public:
    LPFilter1_10_120():IIRFilterBase()
    {
      NumberOfCoefficients = 1;
      FGain = 2.11324865405187E-001;

      InputCoefficients[0] = 1.00000000000000E+000;

      OutputCoefficients[0] = 5.77350269189626E-001;
    }
};



// Butterworth, Bandpass, order = 8, f1 = 8, f2 = 12, SR = 120
class  BPFilter8_8_12_120 : public IIRFilterBase
{
  public:
    BPFilter8_8_12_120():IIRFilterBase()
    {
      NumberOfCoefficients = 16;
      FGain = 8.69475507505079E-009;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 0.00000000000000E+000;
      InputCoefficients[2] = -8.00000000000000E+000;
      InputCoefficients[3] = 0.00000000000000E+000;
      InputCoefficients[4] = 2.80000000000000E+001;
      InputCoefficients[5] = 0.00000000000000E+000;
      InputCoefficients[6] = -5.60000000000000E+001;
      InputCoefficients[7] = 0.00000000000000E+000;
      InputCoefficients[8] = 7.00000000000000E+001;
      InputCoefficients[9] = 0.00000000000000E+000;
      InputCoefficients[10] = -5.60000000000000E+001;
      InputCoefficients[11] = 0.00000000000000E+000;
      InputCoefficients[12] = 2.80000000000000E+001;
      InputCoefficients[13] = 0.00000000000000E+000;
      InputCoefficients[14] = -8.00000000000000E+000;
      InputCoefficients[15] = 0.00000000000000E+000;

      OutputCoefficients[0] = -3.40920506433274E-001;
      OutputCoefficients[1] = 5.06859971943448E+000;
      OutputCoefficients[2] = -3.60826644449233E+001;
      OutputCoefficients[3] = 1.63061063971468E+002;
      OutputCoefficients[4] = -5.23096705537215E+002;
      OutputCoefficients[5] = 1.26228637384009E+003;
      OutputCoefficients[6] = -2.36905177220530E+003;
      OutputCoefficients[7] = 3.52633524401778E+003;
      OutputCoefficients[8] = -4.20644114991499E+003;
      OutputCoefficients[9] = 4.03428039396457E+003;
      OutputCoefficients[10] = -3.10069170235300E+003;
      OutputCoefficients[11] = 1.89008458729427E+003;
      OutputCoefficients[12] = -8.96066563859580E+002;
      OutputCoefficients[13] = 3.19547672562577E+002;
      OutputCoefficients[14] = -8.08905363319283E+001;
      OutputCoefficients[15] = 1.29980681745250E+001;
    }
};


// Butterworth, Bandpass, order = 8, f1 = 12, f2 = 20, SR = 120
class  BPFilter8_12_20_120 : public IIRFilterBase
{
  public:
    BPFilter8_12_20_120():IIRFilterBase()
    {
      NumberOfCoefficients = 16;
      FGain = 1.40954167498536E-006;

      InputCoefficients[0] = 1.00000000000000E+000;
      InputCoefficients[1] = 0.00000000000000E+000;
      InputCoefficients[2] = -8.00000000000000E+000;
      InputCoefficients[3] = 0.00000000000000E+000;
      InputCoefficients[4] = 2.80000000000000E+001;
      InputCoefficients[5] = 0.00000000000000E+000;
      InputCoefficients[6] = -5.60000000000000E+001;
      InputCoefficients[7] = 0.00000000000000E+000;
      InputCoefficients[8] = 7.00000000000000E+001;
      InputCoefficients[9] = 0.00000000000000E+000;
      InputCoefficients[10] = -5.60000000000000E+001;
      InputCoefficients[11] = 0.00000000000000E+000;
      InputCoefficients[12] = 2.80000000000000E+001;
      InputCoefficients[13] = 0.00000000000000E+000;
      InputCoefficients[14] = -8.00000000000000E+000;
      InputCoefficients[15] = 0.00000000000000E+000;

      OutputCoefficients[0] = -1.14436241078234E-001;
      OutputCoefficients[1] = 1.42049214774546E+000;
      OutputCoefficients[2] = -8.89413227017214E+000;
      OutputCoefficients[3] = 3.67840464702818E+001;
      OutputCoefficients[4] = -1.11709149031951E+002;
      OutputCoefficients[5] = 2.63004466830864E+002;
      OutputCoefficients[6] = -4.95213124918624E+002;
      OutputCoefficients[7] = 7.59367324965901E+002;
      OutputCoefficients[8] = -9.57468961311452E+002;
      OutputCoefficients[9] = 9.95703909052396E+002;
      OutputCoefficients[10] = -8.51477547456860E+002;
      OutputCoefficients[11] = 5.93049235073864E+002;
      OutputCoefficients[12] = -3.30380419902383E+002;
      OutputCoefficients[13] = 1.42699006140734E+002;
      OutputCoefficients[14] = -4.52568857216686E+001;
      OutputCoefficients[15] = 9.47758315842857E+000;
    }
};


// Butterworth, Lowpass, order = 1, f = 1, SR = 10
class  MyFilter_LP : public IIRFilterBase
{
  public:
    MyFilter_LP():IIRFilterBase()
    {
        NumberOfCoefficients = 1;
        FGain = 6.15117685036216E-002;

        InputCoefficients[0] = 1.00000000000000E+000;

        OutputCoefficients[0] = 8.76976462992757E-001;
    }
};

class  MyFilterAlpha : public IIRFilterBase
{
  public:
    MyFilterAlpha():IIRFilterBase()
    {
      NumberOfCoefficients = 4;
      FGain =  3.62201289078552E-003;

      InputCoefficients[0] =  1;
      InputCoefficients[1] =  0;
      InputCoefficients[2] = -2;
      InputCoefficients[3] =  0;

      OutputCoefficients[0] = -0.837181651256023;
      OutputCoefficients[1] = 3.38267073095038;
      OutputCoefficients[2] = -5.24706082660941;
      OutputCoefficients[3] = 3.69765597105537;
    }
};


class FilterEMG
{
public:
    FilterEMG() {
      f50hz = new MyFilter_50Hz();
      wf = new WaveFilter(192, 0);
      lp = new MyFilter_LP();
      counter = 0;
      calculated_value = 0.0;
    }

    ~FilterEMG() {
        delete(f50hz);
        delete(wf);
        delete(lp);
    }

    MyFilter_50Hz *f50hz;
    WaveFilter *wf;
    MyFilter_LP *lp;

    float filter(float v) {
      v = wf -> filter(f50hz -> filter(v));
      if (counter++ % 10 == 0) {
        calculated_value = lp -> filter(v);
      }

      return calculated_value;
    }
  protected:
    unsigned int counter;
    float calculated_value;
};


class FilterEEG
{
public:
    FilterEEG() {
      f50hz = new MyFilter_50Hz();
      wf = new WaveFilter(192, 0);
      lp = new MyFilter_LP();
      counter = 0;
      calculated_value = 0.0;
    }

    ~FilterEEG() {
        delete(f50hz);
        delete(wf);
        delete(lp);
    }

    MyFilter_50Hz *f50hz;
    WaveFilter *wf;
    MyFilter_LP *lp;

    float filter(float v) {
      v = wf -> filter(f50hz -> filter(v));
      if (counter++ % 10 == 0) {
        calculated_value = lp -> filter(v);
      }

      return calculated_value;
    }
  protected:
    unsigned int counter;
    float calculated_value;
};
*/

#endif //_UNIOR_FILTERS_H
